Simple php crawler and simple drupal plugin for search.
please refer readmeImp for important instructions
